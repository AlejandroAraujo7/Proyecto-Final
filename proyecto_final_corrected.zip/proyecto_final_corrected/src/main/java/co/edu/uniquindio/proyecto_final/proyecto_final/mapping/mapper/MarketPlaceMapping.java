package co.edu.uniquindio.proyecto_final.co.edu.uniquindio.proyecto_final.proyecto_final.mapping.mapper;

public class MarketPlaceMapping {
}
