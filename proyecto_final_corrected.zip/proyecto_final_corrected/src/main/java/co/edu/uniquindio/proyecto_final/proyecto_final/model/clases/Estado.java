package co.edu.uniquindio.proyecto_final.proyecto_final.model.clases;

// Enum Estado

public enum Estado {
    VENDIDO,
    PUBLICADO,
    CANCELADO;
}
